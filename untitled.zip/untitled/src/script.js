// Lesson and quiz dataset
const lessons = {
    math: {
        title: "Magical Math! ➕",
        content: "Did you know that Math is like a puzzle? Let's try one! If you have 3 space apples and a friendly alien gives you 5 more, how many do you have?",
        interactive: "Show Answer",
        answer: "You have 8 space apples! 🍎🛸 (3 + 5 = 8)",
        fact: "The number 0 was invented last! Before that, ancient systems just left empty spaces!"
    },
    science: {
        title: "Super Science! 🧪",
        content: "Our world is made of tiny building blocks called atoms. Even water is made of atoms! Water is called H2O because it has 2 Hydrogen atoms and 1 Oxygen atom.",
        interactive: "Reveal Fun Fact",
        answer: "Sound travels 4 times faster through water than it does through the air!",
        fact: "Hot water can actually freeze faster than cold water under certain conditions! This is called the Mpemba effect."
    },
    history: {
        title: "Exciting History! 🏰",
        content: "Step into our time machine! Hundreds of years ago, knights lived in castles and wore heavy suits of metal armor to protect themselves.",
        interactive: "Knight Secret",
        answer: "A suit of knight's armor was so heavy (around 50 pounds!) that knights needed help just to climb onto their horses!",
        fact: "The Great Pyramid of Giza was the tallest man-made structure in the world for over 3,800 years!"
    },
    english: {
        title: "Awesome English! 📝",
        content: "Words are super powerful. A sentence that contains every single letter in the alphabet is called a 'pangram'.",
        interactive: "See a Pangram",
        answer: '"The quick brown fox jumps over the lazy dog" uses all 26 letters of the English alphabet!',
        fact: "The word 'alphabet' comes from the first two letters of the Greek alphabet: Alpha and Beta."
    },
    french: {
        title: "Bonjour! Let's Learn French 🇫🇷",
        content: "French is a beautiful language spoken in France, Canada, and many other countries. Let's learn how to greet people!",
        interactive: "Translate Greetings",
        answer: "Bonjour = Hello! <br> Merci = Thank you! <br> Au revoir = Goodbye!",
        fact: "French was the official language of England for about 300 years!"
    },
    spanish: {
        title: "¡Hola! Let's Learn Spanish 🇪🇸",
        content: "Spanish is spoken by over 500 million people around the world! Let's learn to count to three in Spanish.",
        interactive: "Learn to Count",
        answer: "Uno = One (1)<br>Dos = Two (2)<br>Tres = Three (3)",
        fact: "In Spanish, exclamation marks are written upside down at the start of sentences, like this: ¡Hola!"
    },
    italian: {
        title: "Ciao! Let's Learn Italian 🇮🇹",
        content: "Italy is famous for art, history, and delicious food like pizza and pasta! Let's learn some food words in Italian.",
        interactive: "Translate Foods",
        answer: "Gelato = Ice Cream 🍦<br>Formaggio = Cheese 🧀<br>Pomodoro = Tomato 🍅",
        fact: "The word 'Ciao' can mean both 'Hello' and 'Goodbye' in Italian!"
    }
};

// --- Part A: Filtering Dashboard Subjects ---
const navButtons = document.querySelectorAll('.nav-btn');
const cards = document.querySelectorAll('.subject-card');

navButtons.forEach(button => {
    button.addEventListener('click', (e) => {
        // Clear active status on tabs and add to clicked tab
        navButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        
        // Determine filter target
        let category = 'all';
        if(button.id === 'btn-subjects') category = 'subjects';
        if(button.id === 'btn-languages') category = 'languages';

        // Filter elements
        cards.forEach(card => {
            if (category === 'all' || card.getAttribute('data-type') === category) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    });
});

// --- Part B: Loading Lessons dynamically ---
cards.forEach(card => {
    card.addEventListener('click', () => {
        const subjectKey = card.getAttribute('data-subject');
        const lesson = lessons[subjectKey];
        const classroom = document.getElementById('classroom');
        
        // Inject modern template content safely
        classroom.innerHTML = `
            <h2 class="display-title">${lesson.title}</h2>
            <p class="lesson-content">${lesson.content}</p>
            <div id="answerArea">
                <button class="action-btn" id="action-trigger">${lesson.interactive}</button>
            </div>
            <div class="fun-fact-box">
                <strong>💡 Quick Fact:</strong> ${lesson.fact}
            </div>
        `;

        // Handle inner reveal interactions inside the generated components
        document.getElementById('action-trigger').addEventListener('click', () => {
            document.getElementById('answerArea').innerHTML = `
                <p style="font-size: 1.3rem; color: #4ECDC4; font-weight: bold; margin-top: 15px;">
                    🎉 ${lesson.answer}
                </p>
            `;
        });
        
        classroom.scrollIntoView({ behavior: 'smooth' });
    });
});